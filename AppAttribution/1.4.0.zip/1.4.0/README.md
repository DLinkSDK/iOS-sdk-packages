# client-sdk-swift

## Step 1: Get the Appid

Register an account at [https://console.dlink.cloud/](https://console.dlink.cloud). After creating an app on the platform, get the corresponding Appid of the app.

## Step 2: Download the SDK

## Step 3: Initialize the SDK 

### (1) configure and setup AttributionManager and start it
```swift
import AppAttribution

func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {    

    // start attribution manager
    AttributionManager.start()

    return true
}
```

### (2) **[!! IMPORTANT !!] Allow to make app attribution report**
```swift
// if you're ready to report app attribution, call readyToReport to start the process
// strongly recommended to begin report after you get your att auth

AttributionManager.readyToReport()
```
### (3) Implement the delegate
```swift
extension AppDelegate: AttributionManagerDelegate {
    func appAttributionDidFinish(matched: Bool, info: [String : Any]) {
        // app attribution finished
        if matched {
            print("attribution matched, get info \(info)")
            // you can fetch your campaign info from here
            if let campaignInfo = info[AttributionParamKey.campaignInfoKey] as? [String: Any] {
                // check your campaign info params here
                print("campaign info \(campaignInfo)")
            }
        } else {
          print("attribution not matched")
        }
    }

    func appAttributionDidFail(error: any Error) {
        print("attribution failed \(error)")
    }
}
```
