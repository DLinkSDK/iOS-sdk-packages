# IPDetector

## create detector
```swift
let detector = IPDetector(name: host, ip: ip, port: 443)
detector.delegate = self
```

## start detect
```swift
detector.fetchIP()
```

## get the ip
```swift
extension ViewController: IPDetectorDelegate {
    func ip(detector: IPDetector, didFinish result: Result<[String], Error>) {
        print("\(detector.name): \(detector.ip) did finish with result \(result)")
    }
}
```
