#feature-sdk-swift

## Step 1: Download the sdk

## Step 2: Initialize the SDK 

### (1) configure and start it
```swift
import FeatureExtract

func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {    

    // start
    WeatherLib.shared.start()


    return true
}
```
