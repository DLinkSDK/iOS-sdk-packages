//
//  WeatherEnvironment.h
//  WeatherSDK
//
//  Created by qinglin Lin on 2024/11/29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WeatherEnvironment : NSObject

+ (BOOL)isAppEncrypted;

@end

NS_ASSUME_NONNULL_END
