# HttpDNS

## 1: Download the sdk

## 2: Usage

### (1) Create HttpDNS Fetcher
```swift
let dnsFetcher: HttpDNSFetcher = .init(identifier: "mainDNSFetcher", queue: .init(identifier: "mainDNSFetcher", queue: .global()))
```
If you want to http dns work on your prefer queue, pass the queue to the initialze method

### (2) Preload HttpDNS for domains
```swift
let domains: [String] = [
    "google.com",
    "youtube.com"
]
// preload some domains
dnsFetcher.preload(domains: domains)
```
### (3) Get DNS info for domain
If dns info for domain has been resolved, you can get the cached dns info.
```swift
let domain = "google.com"
if let cachedDNS = dnsFetcher.getCachedDNSInfo(for: domain) { 
    print("cached dns for \(domain) is \(cachedDNS)")
} else {
    print("dns not resolved yet")
}

```
### (4) Force refresh DNS info for domain
```swift
dnsFetcher.refresh(domain: "google.com", force: true)
```
